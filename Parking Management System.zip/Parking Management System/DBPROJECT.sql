-- =====================================
-- CREATE DATABASE + SCHEMA
-- =====================================

DROP DATABASE IF EXISTS ParkingDB;
CREATE DATABASE ParkingDB;

USE ParkingDB;

-- =====================================
-- CREATE SCHEMA
-- =====================================

CREATE SCHEMA IF NOT EXISTS ParkingSchema;

-- =====================================
-- TABLES
-- =====================================

CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Phone VARCHAR(15) UNIQUE
);

CREATE TABLE Vehicles (
    VehicleID INT AUTO_INCREMENT PRIMARY KEY,
    PlateNo VARCHAR(20) UNIQUE,
    Type VARCHAR(20),
    UserID INT,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE Parking_Area (
    AreaID INT AUTO_INCREMENT PRIMARY KEY,
    AreaName VARCHAR(50),
    Location VARCHAR(100)
);

CREATE TABLE Parking_Slot (
    SlotID INT AUTO_INCREMENT PRIMARY KEY,
    AreaID INT,
    Status ENUM('FREE','OCCUPIED') DEFAULT 'FREE',
    FOREIGN KEY (AreaID) REFERENCES Parking_Area(AreaID)
);

CREATE TABLE Parking_Record (
    RecordID INT AUTO_INCREMENT PRIMARY KEY,
    VehicleID INT,
    SlotID INT,
    EntryTime DATETIME,
    ExitTime DATETIME,
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID),
    FOREIGN KEY (SlotID) REFERENCES Parking_Slot(SlotID)
);

CREATE TABLE Payment (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    RecordID INT,
    Amount DECIMAL(10,2),
    PaymentDate DATETIME,
    FOREIGN KEY (RecordID) REFERENCES Parking_Record(RecordID)
);

-- =====================================
-- INSERT DATA
-- =====================================

INSERT INTO Users (Name, Phone) VALUES 
('Ali', '03001234567'),
('Ahmed', '03111234567'),
('Sara', '03221234567');

INSERT INTO Vehicles (PlateNo, Type, UserID) VALUES
('ABC-123', 'Car', 1),
('XYZ-789', 'Bike', 2),
('DEF-456', 'Car', 3);

INSERT INTO Parking_Area (AreaName, Location) VALUES
('Basement', 'Block A'),
('Ground Floor', 'Block B');

INSERT INTO Parking_Slot (AreaID, Status) VALUES
(1, 'FREE'),
(1, 'OCCUPIED'),
(2, 'FREE'),
(2, 'OCCUPIED');

INSERT INTO Parking_Record (VehicleID, SlotID, EntryTime, ExitTime) VALUES
(1, 2, NOW() - INTERVAL 1 DAY, NOW()),
(2, 4, NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 1 DAY);

INSERT INTO Payment (RecordID, Amount, PaymentDate) VALUES
(1, 500, NOW()),
(2, 300, NOW() - INTERVAL 1 DAY);

-- =====================================
-- TRIGGER
-- =====================================

DELIMITER $$

CREATE TRIGGER update_slot_status
AFTER INSERT ON Parking_Record
FOR EACH ROW
BEGIN
    UPDATE Parking_Slot
    SET Status = 'OCCUPIED'
    WHERE SlotID = NEW.SlotID;
END$$

DELIMITER ;

-- =====================================
-- ADVANCED QUERIES
-- =====================================

-- 1. FREE SLOTS
SELECT * FROM Parking_Slot
WHERE Status = 'FREE';

-- 2. OCCUPIED SLOTS
SELECT * FROM Parking_Slot
WHERE Status = 'OCCUPIED';

-- 3. USERS WITH VEHICLES
SELECT U.Name, U.Phone, V.PlateNo, V.Type
FROM Users U
JOIN Vehicles V
ON U.UserID = V.UserID;

-- 4. CURRENTLY PARKED VEHICLES
SELECT V.PlateNo, P.EntryTime
FROM Vehicles V
JOIN Parking_Record P
ON V.VehicleID = P.VehicleID
WHERE P.ExitTime IS NULL;

-- 5. PARKING DURATION
SELECT RecordID,
       VehicleID,
       TIMESTAMPDIFF(HOUR, EntryTime, ExitTime) AS Duration_Hours
FROM Parking_Record;

-- 6. BILL CALCULATION
SELECT RecordID,
       TIMESTAMPDIFF(HOUR, EntryTime, ExitTime) * 50 AS Bill
FROM Parking_Record;

-- 7. TOTAL REVENUE
SELECT SUM(Amount) AS Total_Revenue
FROM Payment;

-- 8. DAILY REVENUE
SELECT DATE(PaymentDate) AS Day,
       SUM(Amount) AS Daily_Revenue
FROM Payment
GROUP BY DATE(PaymentDate)
ORDER BY Day;

-- 9. MOST USED SLOT
SELECT SlotID,
       COUNT(*) AS Usage_Count
FROM Parking_Record
GROUP BY SlotID
ORDER BY Usage_Count DESC;

-- 10. VEHICLES COMPLETED PARKING
SELECT PlateNo
FROM Vehicles
WHERE VehicleID IN (
    SELECT VehicleID
    FROM Parking_Record
    WHERE ExitTime IS NOT NULL
);

-- 11. TOTAL OCCUPIED SLOTS
SELECT COUNT(*) AS Occupied_Slots
FROM Parking_Slot
WHERE Status = 'OCCUPIED';

-- 12. TOTAL FREE SLOTS
SELECT COUNT(*) AS Free_Slots
FROM Parking_Slot
WHERE Status = 'FREE';

-- 13. FULL DETAILS
SELECT U.Name,
       V.PlateNo,
       P.SlotID,
       P.EntryTime,
       P.ExitTime
FROM Parking_Record P
JOIN Vehicles V
ON P.VehicleID = V.VehicleID
JOIN Users U
ON V.UserID = U.UserID;

-- 14. AREA-WISE SLOT COUNT
SELECT AreaID,
       COUNT(*) AS Total_Slots
FROM Parking_Slot
GROUP BY AreaID;

-- 15. AREA-WISE OCCUPIED SLOTS
SELECT AreaID,
       COUNT(*) AS Occupied_Slots
FROM Parking_Slot
WHERE Status = 'OCCUPIED'
GROUP BY AreaID;